import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { RouterModule } from '@angular/router';
import {HomePageComponent} from './components/homepage.component';

@NgModule({
  imports:      [ BrowserModule,RouterModule.forRoot([
    {path:'',component:HomePageComponent}])],
  declarations: [ AppComponent ,HomePageComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
