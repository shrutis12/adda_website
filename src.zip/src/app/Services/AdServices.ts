import {Injectable} from '@angular/core';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()

export class AdvertisementService{
    constructor(private _http:Http){

    }
    ads:Array<any>=[];
    addAdvertisement(item:any){
        let url = "http://192.168.3.144:9000/postAd";
        let headers = new Headers();
        headers.append('auth-token', '5976ea571c0edf75e32798d7');
        headers.append('Content-Type', 'application/json');

        let options = new RequestOptions({ headers: headers });
        let jsonReq = {title: item.title, name: item.name, category: item.category, description: item.description};
        
        let obj= this._http.post(url, jsonReq, options)
			.map((response: Response)=>response.json());
            obj.subscribe((data)=>console.log(data));

    }

    getAdvertisments(){
         let url = "http://192.168.3.144:9000/posts";
        let headers = new Headers();
        headers.append('auth-token', '5976ea571c0edf75e32798d7');
       
       let options = new RequestOptions({ headers: headers });
       let obj= this._http.get(url, options)
			.map((response: Response)=>response.json());
            obj.subscribe((data)=>console.log(data));
            return obj;
    }

    deleteAdvertisement(id:any){
        let url = "http://192.168.3.144:9000/post?postId=";
        let headers = new Headers();
        headers.append('auth-token', '5976ea571c0edf75e32798d7');

        return this._http.delete(url+id).map((response:Response)=>response.json());
    }

    getAdCategories(){
         let url = "http://192.168.3.144:9000/categories";
         return this._http.get(url).map((response:Response)=>response.json());

    }
}