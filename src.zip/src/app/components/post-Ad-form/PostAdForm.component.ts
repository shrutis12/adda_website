import {Component} from '@angular/core';
import {AdvertisementService} from '../../Services/AdServices';
@Component({
    selector:'post-Ad',
    templateUrl:`./PostAd.html`,
    styleUrls:['./PostAdform.css'],
    providers:[AdvertisementService]
    
})

export class PostAdFormComponent{
   title:any="";
   category:Array<any>=[];
   categories:Array<any>=[];
   name:any="";
   description:any="";
   constructor(private adService:AdvertisementService){}

   onSubmit(name:any,category:any,title:any,description:any) {
        let adObject={
            title:title,
            category:category,
            name:name,
            description:description
            
        }
        this.adService.addAdvertisement(adObject);
   }

   getCategory(){
       this.adService.getAdCategories().subscribe((data)=>
       {
            this.categories=data.data.itemList;
            for(let item of this.categories)
            {
                this.category.push(item.name);
            }
            console.log(this.category);
            return this.category;
       });
   }
    
}