import {Component} from '@angular/core';
import {AdvertisementService} from '../../Services/AdServices';
@Component({
    selector:'user-profile',
    templateUrl:`./user-profile-page.html`,
    styleUrls:['./user_profile_page.css'],
    providers:[AdvertisementService]
    
})

export class UserProfilePageComponent{
    constructor(private adService:AdvertisementService){}
    advertisements:Array<any>=[];
    product_object:any={};
    getMyAds(){
        //console.log(this.advertisements);
        this.adService.getAdvertisments().subscribe((data)=>
        {
            this.advertisements= data.data.mypostList;
        
            console.log(this.advertisements);    
        });
        
    }

    deleteObject(index:number){
        let deleteAd:Array<any>=[];
        deleteAd=this.advertisements[index];

        this.adService.deleteAdvertisement(deleteAd.id).subscribe((data:any)=>
        {
            this.adService.getAdvertisments().subscribe((data)=>
        {
            this.advertisements= data.data.mypostList;
        
                
        });
        });

    }


    





    
}