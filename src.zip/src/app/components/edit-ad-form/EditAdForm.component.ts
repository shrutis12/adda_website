import {Component} from '@angular/core';

@Component({
    selector:'edit-ad',

})

export class EditAdFormComponent{
    
}