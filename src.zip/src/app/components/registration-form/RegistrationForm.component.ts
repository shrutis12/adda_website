import {Component} from '@angular/core';
import {Router} from '@angular/router';
@Component({
    selector:'register',
    templateUrl:`./RegistrationForm.html`,
    styleUrls:['./RegistrationForm.css']
})
export class RegistrationFormComponent{

}