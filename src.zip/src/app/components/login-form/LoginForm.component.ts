import {Component} from '@angular/core';
import {Router} from '@angular/router';

@Component({
    selector:'login',
    templateUrl:`./LoginForm.html`,
    styleUrls:['./LoginForm.css']
})
export class LoginFormComponent{
    constructor(private router:Router){}
    onClick(){
        this.router.navigate(['/login']);
    }

}